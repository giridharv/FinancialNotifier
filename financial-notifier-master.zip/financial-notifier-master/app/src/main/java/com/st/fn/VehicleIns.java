package com.st.fn;

/**
 * Created by giri on 4/15/2015.
 */
public class VehicleIns {
}
