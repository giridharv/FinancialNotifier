package com.st.fn;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class NotifyService extends Service {

	@Override
	public IBinder onBind(Intent arg0) {
		// TODO Auto-generated method stub
		return null;
	}

}
